<?php
// Replace with your OpenAI key
$OPENAI_API_KEY = "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";


$db_host = "localhost";
$db_user = "root";
$db_pass = "Jagan@143";
$db_name = "snapsite";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("DB FAILED: " . $conn->connect_error);
}
?>
